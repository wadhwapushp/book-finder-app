import {combineReducers} from 'redux';
const nameReducer=(state="Programming Challenges",action)=>{
  switch(action.type){
      case "SET_NAME":
       // code to execute
       state =action.payload;
       console.log('nameReducer =' + action.payload) 
      break;
  } 
  return state;
}

let reducers = combineReducers({names:nameReducer});
export default reducers;