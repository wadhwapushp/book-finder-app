import React from 'react';

class Book extends Component {
   
    state = {  }

    constructor(props) {
        super(props);
        this.state = {
            name: props.book.title,
            title: props.book.title ,
            image_url :  props.book.image_url,
            author_name :  props.book.author_name ,
            rating : props.book.average_rating,
            details :{
               description :  props.book.description ,
               ratings_count : '' 
           }
        } 
        console.log('Constructor loaded');
    }
    
    render() { 
        return ( '' );
    }
}
 
export default Book;



