import React, { Component } from 'react';
import './App.css';
import Home from './components/Home/Home';
import SearchBooks from './components/SearchBooks/SearchBooks';
//import bootstrap from  '../../../bootstrap/dist/css/bootstrap.css';


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchword: "Programming Challenges",
    }
  }
  onSearch(newsearchword){
    this.setState({
      searchword:newsearchword
    })
  }
  render() {
    return (
      <div className="App">
       <Home/>
       <SearchBooks/>
      </div>
    );
  }
}

export default App;
