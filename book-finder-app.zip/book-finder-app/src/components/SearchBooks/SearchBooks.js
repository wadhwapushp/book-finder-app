import React, { Component } from 'react';
import axios from 'axios';
import {connect} from 'react-redux';
import BooksList from '../BooksList/BooksList';
var parseString = require('xml2js').parseString;
var XMLParser = require('react-xml-parser');

class SearchBooks extends Component {
    state = {  }
    constructor(props){ super(props); 
         this.state={
             books:[] , searchword: props.searchword 
        }    
        }  
    componentDidMount(){
        //Added delay of 1.01 sec
         var searchkey=  this.props.name
        setTimeout(this.handleGetBooks(searchkey), 1010);
    }

    componentWillReceiveProps(nextProps) {
        console.log("Home:componentWillReceiveProps", nextProps);
        setTimeout(this.handleGetBooks(nextProps.name), 1010);
    }

    handleGetBooks(searchkey){
        var config = {headers: {"X-Requested-With" : "XMLHttpRequest"}};
        var host ='http://cors-anywhere.herokuapp.com/https://www.goodreads.com/' ;
        var searchpage ='search.xml' ;
        var key ='?key=GOODREAD_KEY';
        //var searchWord ='&q=' +'End%20Game%20(Dawson%20Family,%20#2)' ;
        var searchWord ='&q=';       
        var searchUrl = host+searchpage+key+searchWord + searchkey;
        var bestboodkId ='40281801' ;
        var bookpage ='book/show/' ;
    //     var bookUrl = host+bookpage+bestboodkId+key ;
    //     var bookurl2 =host +'book/show/40281801?key=D3CUaCFxKWBS6LCGxZdThw'
    //  //   axios.get(bookurl2,config )
       axios.get(searchUrl,config )
        .then(response => {
          parseString(response.data.toString('utf8'), (err, result) => {
         //   var xml = new XMLParser().parseFromString(response.data.toString('utf8'), (err, result) => {
            if(err) {
        //     console.log(bookUrl);
        console.log(searchUrl);
             console.log(err);
            } else {
                var books=[];
                var workarr = result.GoodreadsResponse.search[0].results[0].work ;
               this.setState({ books: workarr })
          //  this.setState({ books: xml.getElementsByTagName('title') })
             this.books = result;
             console.log(result) ;
              }
          });  
          
        //   console.log(xml);
        //   console.log(xml.getElementsByTagName('title'));
        })
        
    }

     render() { 
        return ( 
            <div className="row">
                        <div className="col-md-12">
                       Search Results for text= {this.props.name}
                            <BooksList  books={this.state.books}/>
                        </div>
                    </div>
             );
    }

    
}

function mapStateToProps(state){
    console.log('Search book ='+ state.names)
    return{
        name:state.names
    }     
  }
  
  export default connect(mapStateToProps)(SearchBooks);

//export default SearchBooks;