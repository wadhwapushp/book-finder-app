
import React, { Component } from 'react';
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux';
import onSearch from '../../actions';

class Home extends Component {
    state = {}
    render() { 
        return (
            <div>
            <h1> Home Component </h1>
            <input type="text" ref={(input) => this.inputElement = input} />
            <button  onClick={() => this.props.onSearch(this.inputElement.value)}>Search Book </button>
            </div>
             )
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators(onSearch,dispatch)
   }
    export default 
   connect(()=>{return {};},mapDispatchToProps)(Home);
 