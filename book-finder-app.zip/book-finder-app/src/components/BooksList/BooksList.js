import React, { Component } from 'react'
class BooksList extends Component {
    state = {}
    render() {
       
        var mybooks = this.props.books;

       console.log(mybooks) ;
        return ( <div className="container" >

        <h5> BooksList </h5>
            <table className="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                    </tr>
                </thead>
                <tbody>
                {/* {mybook[0].best_book[0].image_url} */}
                    {mybooks.map((book,n)=>{
                                  return (
                                <tr key={n} align='left' >
                                    <td align ='left'>
                                       <img id="{n}" src={book.best_book[0].small_image_url}  />        
                                        &nbsp; &nbsp; &nbsp; &nbsp; 
                                        <a href ='#' onClick= {() =>62571166 }> {book.best_book[0].title}  </a>
                                        {book.average_rating.name} 
                                        {/* {book.best_book[0].id[0]} */}
                                      writen by  {book.best_book[0].author[0].name}
                                        {/* <img id="{n}" src={book.best_book[0].image_url}  />                     */}
                                        </td>  
                                    </tr>
                                );
                           }                  
                    )}
                        </tbody>
            </table>
         </div>)
    }
}

export default BooksList;