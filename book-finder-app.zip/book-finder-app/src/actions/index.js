
const onSearch=(searchword)=>{

  console.log('action ='+searchword);

  return {
      type:"SET_NAME",
      payload:searchword

  }
}

export default {onSearch};